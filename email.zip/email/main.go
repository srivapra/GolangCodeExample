package main

import "email/mail"

// Function main to call SendEmail() function
func main() {

	mail.SendEmail()

}
